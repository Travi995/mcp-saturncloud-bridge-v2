import { z } from 'zod';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { promises as fs } from 'fs';
import * as path from 'path';

export function registerFsTools(server: Server) {
  server.tool({
    name: 'fs.listDir',
    description: 'List directory entries (files and folders).',
    schema: z.object({ dir: z.string() }),
    handler: async ({ dir }) => {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      return entries.map((e) => ({ name: e.name, type: e.isDirectory() ? 'dir' : 'file' }));
    },
  });

  server.tool({
    name: 'fs.createFile',
    description: 'Create a text/binary file. Set overwrite=true to replace.',
    schema: z.object({ file: z.string(), content: z.string().default(''), overwrite: z.boolean().default(false) }),
    handler: async ({ file, content, overwrite }) => {
      const exists = await existsAsync(file);
      if (exists && !overwrite) throw new Error('File exists. Set overwrite=true to replace.');
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(file, content);
      return { ok: true, file };
    },
  });

  server.tool({
    name: 'fs.readFile',
    description: 'Read a file. Optionally limit bytes.',
    schema: z.object({ file: z.string(), maxBytes: z.number().int().positive().optional() }),
    handler: async ({ file, maxBytes }) => {
      const buf = await fs.readFile(file);
      const out = maxBytes ? buf.subarray(0, maxBytes) : buf;
      return { file, content: out.toString('utf-8') };
    },
  });

  server.tool({
    name: 'fs.writeFile',
    description: 'Write or append to a file.',
    schema: z.object({ file: z.string(), content: z.string(), append: z.boolean().default(false) }),
    handler: async ({ file, content, append }) => {
      await fs.mkdir(path.dirname(file), { recursive: true });
      if (append) await fs.appendFile(file, content);
      else await fs.writeFile(file, content);
      return { ok: true, file };
    },
  });

  server.tool({
    name: 'fs.createNotebook',
    description: 'Create a minimal Jupyter .ipynb notebook at path.',
    schema: z.object({ file: z.string(), title: z.string().default('Notebook'), code: z.string().default('print("hello from MCP")') }),
    handler: async ({ file, title, code }) => {
      const nb = {
        cells: [
          { cell_type: 'markdown', metadata: {}, source: [`# ${title}\n`] },
          { cell_type: 'code', metadata: {}, source: [code + '\n'], outputs: [], execution_count: null },
        ],
        metadata: { kernelspec: { name: 'python3', display_name: 'Python 3' }, language_info: { name: 'python' } },
        nbformat: 4,
        nbformat_minor: 5,
      };
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(file, JSON.stringify(nb, null, 2));
      return { ok: true, file };
    },
  });
}

async function existsAsync(p: string) {
  try { await fs.stat(p); return true; } catch { return false; }
}
