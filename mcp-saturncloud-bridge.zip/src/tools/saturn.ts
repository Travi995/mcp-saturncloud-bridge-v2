import { z } from 'zod';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { SaturnClient } from '../saturnClient.js';

export function registerSaturnTools(server: Server, client: SaturnClient) {
  // Workspaces
  server.tool({
    name: 'saturn.listWorkspaces',
    description: 'List Saturn Cloud workspaces.',
    schema: z.object({ page: z.number().optional(), page_size: z.number().optional(), org_id: z.string().optional(), group_id: z.string().optional(), include_groups: z.boolean().optional() }),
    handler: async (args) => client.get('/api/workspaces', args as any),
  });

  server.tool({
    name: 'saturn.startWorkspace',
    description: 'Start a workspace by ID. Optionally enable debug mode.',
    schema: z.object({ workspace_id: z.string(), debug_mode: z.boolean().optional() }),
    handler: async ({ workspace_id, debug_mode }) => client.post(`/api/workspaces/${workspace_id}/start`, debug_mode ? { debug_mode } : undefined),
  });

  server.tool({
    name: 'saturn.stopWorkspace',
    description: 'Stop a workspace by ID.',
    schema: z.object({ workspace_id: z.string() }),
    handler: async ({ workspace_id }) => client.post(`/api/workspaces/${workspace_id}/stop`),
  });

  server.tool({
    name: 'saturn.workspaceLogs',
    description: 'Fetch workspace logs. Optionally return only the last N lines.',
    schema: z.object({ workspace_id: z.string(), tail: z.number().int().positive().optional() }),
    handler: async ({ workspace_id, tail }) => {
      const data: any = await client.get(`/api/workspaces/${workspace_id}/logs`);
      if (tail) {
        const lines = Array.isArray(data?.lines) ? data.lines.slice(-tail) : [];
        return { workspace_id, lines };
      }
      return data;
    },
  });

  // Deployments
  server.tool({
    name: 'saturn.startDeployment',
    description: 'Start a deployment by ID.',
    schema: z.object({ deployment_id: z.string() }),
    handler: async ({ deployment_id }) => client.post(`/api/deployments/${deployment_id}/start`),
  });

  server.tool({
    name: 'saturn.stopDeployment',
    description: 'Stop a deployment by ID.',
    schema: z.object({ deployment_id: z.string() }),
    handler: async ({ deployment_id }) => client.post(`/api/deployments/${deployment_id}/stop`),
  });

  server.tool({
    name: 'saturn.deploymentLogs',
    description: 'Fetch deployment logs. Optionally return only the last N lines.',
    schema: z.object({ deployment_id: z.string(), tail: z.number().int().positive().optional() }),
    handler: async ({ deployment_id, tail }) => {
      const data: any = await client.get(`/api/deployments/${deployment_id}/logs`);
      if (tail) {
        const lines = Array.isArray(data?.lines) ? data.lines.slice(-tail) : [];
        return { deployment_id, lines };
      }
      return data;
    },
  });

  // Jobs
  server.tool({
    name: 'saturn.jobStart',
    description: 'Execute a job now (by deployment_id).',
    schema: z.object({ deployment_id: z.string() }),
    handler: async ({ deployment_id }) => client.post(`/api/jobs/${deployment_id}/start`),
  });

  server.tool({
    name: 'saturn.jobSchedule',
    description: 'Create/replace a cron schedule for a job (by deployment_id). Example cron: "0 3 * * *"',
    schema: z.object({ deployment_id: z.string(), cron: z.string() }),
    handler: async ({ deployment_id, cron }) => client.post(`/api/jobs/${deployment_id}/schedule`, { schedule: cron }),
  });

  server.tool({
    name: 'saturn.jobUnschedule',
    description: 'Remove the cron schedule for a job (by deployment_id).',
    schema: z.object({ deployment_id: z.string() }),
    handler: async ({ deployment_id }) => client.post(`/api/jobs/${deployment_id}/unschedule`),
  });

  // Secrets
  server.tool({
    name: 'saturn.listSecrets',
    description: 'List secrets (supports common filters/pagination).',
    schema: z.object({ owner_id: z.string().optional(), owner_name: z.string().optional(), user_id: z.string().optional(), group_id: z.string().optional(), org_id: z.string().optional(), page: z.number().optional(), page_size: z.number().optional() }),
    handler: async (args) => client.get('/api/secrets', args as any),
  });

  server.tool({
    name: 'saturn.createSecret',
    description: 'Create a secret.',
    schema: z.object({ owner_id: z.string(), owner_name: z.string().optional(), user_id: z.string().nullable().optional(), group_id: z.string().nullable().optional(), org_id: z.string(), name: z.string(), access: z.enum(['owner', 'org', 'group']), value: z.string() }),
    handler: async (args) => client.post('/api/secrets', args),
  });

  server.tool({
    name: 'saturn.attachSecret',
    description: 'Attach a secret to a resource (workspaces|jobs|deployments).',
    schema: z.object({ resource_type: z.enum(['workspaces', 'jobs', 'deployments']), resource_id: z.string(), secret_id: z.string(), description: z.string().optional() }),
    handler: async ({ resource_type, resource_id, secret_id, description }) => client.post(`/api/${resource_type}/${resource_id}/secrets`, { secret: { id: secret_id }, description }),
  });

  // Recipes
  server.tool({
    name: 'saturn.upsertRecipe',
    description: 'Create or update a recipe (workspace|deployment|job|image). Provide raw JSON object.',
    schema: z.object({ recipe: z.any() }),
    handler: async ({ recipe }) => client.put('/api/recipes', recipe),
  });

  server.tool({
    name: 'saturn.listRecipes',
    description: 'List recipes (optionally filter by type).',
    schema: z.object({ type: z.enum(['workspace', 'deployment', 'job', 'image']).optional() }),
    handler: async ({ type }) => {
      const res: any = await client.get('/api/recipes');
      if (!type) return res;
      const items = Array.isArray(res?.items) ? res.items.filter((r: any) => r?.type === type) : res;
      return { items };
    },
  });

  server.tool({
    name: 'saturn.getRecipe',
    description: 'Get a recipe by type and name.',
    schema: z.object({ recipe_type: z.enum(['workspace', 'deployment', 'job', 'image']), name: z.string() }),
    handler: async ({ recipe_type, name }) => client.get(`/api/recipes/${recipe_type}/${encodeURIComponent(name)}`),
  });

  // Raw proxy (restricted)
  server.tool({
    name: 'saturn.rawGet',
    description: 'Advanced: GET any /api/* path with optional query. Use carefully.',
    schema: z.object({ path: z.string(), query: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).optional() }),
    handler: async ({ path, query }) => {
      if (!path.startsWith('/api/')) throw new Error('path must start with /api/');
      return client.get(path, query as any);
    },
  });

  server.tool({
    name: 'saturn.rawPost',
    description: 'Advanced: POST any /api/* path with JSON body.',
    schema: z.object({ path: z.string(), body: z.any().optional() }),
    handler: async ({ path, body }) => {
      if (!path.startsWith('/api/')) throw new Error('path must start with /api/');
      return client.post(path, body);
    },
  });
}
